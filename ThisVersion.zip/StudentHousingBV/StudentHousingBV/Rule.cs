﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentHousingBV
{
    class Rule
    {
        private String rule;
        
        public Rule(String Rule)
        {
            rule = Rule;
        }
        public String getRule()
        {
            return rule;
        }
    }
}
