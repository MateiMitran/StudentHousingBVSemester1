﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentHousingBV
{
    public partial class TenantAnnouncements : Form
    {
        private List<int> votes;
       // private List<TenantClass> alltenants;
        public int accept;
        public TenantAnnouncements()
        {
            InitializeComponent();
            votes = new List<int>();
            //alltenants = new List<Tenant>();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TenantAnnouncements_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //this.label4.Text= this.alltenants.addVote(1); //add the vote of the usser
        }
    }
}
