﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentHousingBV
{
    class Task
    {
        private String task;

        public Task(String Task)
        {
           task = Task;
        }
        public String getTask()
        {
            return task;
        }
    }
}
