﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace StudentHousingBV
{
    public partial class CompanyTenants : Form
    {
        private List<TenantClass> allTenants;
        LogInScreen login = (LogInScreen)Application.OpenForms["LogInScreen"];
        public CompanyTenants()
        {
            
            InitializeComponent();
        }

        private void CompanyTenants_Load(object sender, EventArgs e)
        {
            
            allTenants = login.getTenants();
            for (int i = 0; i < allTenants.Count(); i++)
            {
                this.comboBox1.Items.Add(allTenants[i].getName());
            }
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            TenantClass x = new TenantClass(this.textBox1.Text);
            login.addTenant(x);
            String path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"../../users.txt");
            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(path, true))
            {
                file.WriteLine(this.textBox1.Text + " " + "password" + "user");
            }

        }
    }
}
